
<?php $__env->startSection('content'); ?>
 
<div class="card">
  <div class="card-header" style="background-color:rgb(255, 254, 206)""  ><h1>START<h1></div>
  <div class="card-body"  style="background-color:rgb(198, 238, 250)">
      
      <form action="<?php echo e(url('element')); ?>" method="post" >
        <?php echo csrf_field(); ?>

        <label>Name: </label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        <label>Details:</label></br>
        <input type="text" name="details" id="details" class="form-control"></br>
        <label>Date</label></br>
        <input type="date" name="date" id="date" class="form-control"></br>
        <label>Number:</label></br>
        <input type="number" name="number" id="number" class="form-control"></br>
        <input type="submit" value="ADD" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('elements.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mbayt\Desktop\laravelcrud\laravelcrud\resources\views/elements/create.blade.php ENDPATH**/ ?>