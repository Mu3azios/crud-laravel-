
<?php $__env->startSection('content'); ?>
 
 
<div class="card">
  <div class="card-header"><h5>SHOW RECORD PAGE</h5></div>
  <div class="card-body">
   
 
        <div class="card-body" style="background-color:rgb(255, 254, 206)">
        <h5 class="card-title">Name : <?php echo e($elements->name); ?></h5>
        <h5 class="card-text">details : <?php echo e($elements->details); ?></h5>
        <h5 class="card-text">date : <?php echo e($elements->date); ?></h5>
        <h5 class="card-text">number : <?php echo e($elements->number); ?></h5>
        <button  onclick="history.back()" class="btn btn-success">Back</button>
  </div>
       
    </hr>
  
  </div>
</div>
<?php echo $__env->make('elements.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mbayt\Desktop\laravelcrud\laravelcrud\resources\views/elements/show.blade.php ENDPATH**/ ?>